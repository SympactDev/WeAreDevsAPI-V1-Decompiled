﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("WeAreDevs API v1 CSharp")]
[assembly: AssemblyDescription("Used to build software accessing the Lua C API")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("WeAreDevs_API.Properties")]
[assembly: AssemblyCopyright("MIT")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("6d8a8bf5-f458-403a-a65f-8989c36536fd")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyVersion("1.0.0.0")]
